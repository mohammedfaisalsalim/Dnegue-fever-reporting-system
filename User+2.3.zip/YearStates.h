#pragma once
#include <iostream>
#include <iomanip>


using namespace std;

// Defines the individual elements(node) that will be stored in the linked list.
class YearStates {
public:
    struct StateData {
        int year;
        string ageGroup;
        string Johor, Kedah, Kelantan, Melaka, NegeriSembilan, Pahang, Perak, Perlis, PulauPinang, Sabah, Sarawak, Selangor, Terengganu, WPKualaLumpur, WPLabuan;
        StateData* next;
    };

    StateData* head;

public:
    YearStates(const string& title) : head(nullptr) {
        cout << title << endl;
    }

    ~YearStates() {
        while (head != nullptr) {
            StateData* temp = head;
            head = head->next;
            delete temp;
        }
    }

    void readFromFile(const string& filename) {
        ifstream file(filename);
        if (!file.is_open()) {
            cerr << "Error opening file: " << filename << endl;
            return;
        }

        string line, tahun, ageGroup, Johor, Kedah, Kelantan, Melaka, NegeriSembilan, Pahang, Perak, Perlis, PulauPinang, Sabah, Sarawak, Selangor, Terengganu, WPKualaLumpur, WPLabuan;
        getline(file, line); // Skip header line

        while (getline(file, line)) {
            istringstream iss(line);
            getline(iss, tahun, ',');
            getline(iss, ageGroup, ',');
            getline(iss, Johor, ',');
            getline(iss, Kedah, ',');
            getline(iss, Kelantan, ',');
            getline(iss, Melaka, ',');
            getline(iss, NegeriSembilan, ',');
            getline(iss, Pahang, ',');
            getline(iss, Perak, ',');
            getline(iss, Perlis, ',');
            getline(iss, PulauPinang, ',');
            getline(iss, Sabah, ',');
            getline(iss, Sarawak, ',');
            getline(iss, Selangor, ',');
            getline(iss, Terengganu, ',');
            getline(iss, WPKualaLumpur, ',');
            getline(iss, WPLabuan);

            try {
                int year = stoi(tahun);
                insertToEndList(year, ageGroup, Johor, Kedah, Kelantan, Melaka, NegeriSembilan, Pahang, Perak, Perlis, PulauPinang, Sabah, Sarawak, Selangor, Terengganu, WPKualaLumpur, WPLabuan);
            }
            catch (const exception& e) {
                cerr << "Error converting string to numeric value: " << e.what() << endl;
            }
        }
    }

    void insertToEndList(int year, const string& ageGroup, const string& Johor, const string& Kedah, const string& Kelantan, const string& Melaka, const string& NegeriSembilan, const string& Pahang, const string& Perak, const string& Perlis, const string& PulauPinang, const string& Sabah, const string& Sarawak, const string& Selangor, const string& Terengganu, const string& WPKualaLumpur, const string& WPLabuan) {
        StateData* newNode = new StateData;
        newNode->year = year;
        newNode->ageGroup = ageGroup;
        newNode->Johor = Johor;
        newNode->Kedah = Kedah;
        newNode->Kelantan = Kelantan;
        newNode->Melaka = Melaka;
        newNode->NegeriSembilan = NegeriSembilan;
        newNode->Pahang = Pahang;
        newNode->Perak = Perak;
        newNode->Perlis = Perlis;
        newNode->PulauPinang = PulauPinang;
        newNode->Sabah = Sabah;
        newNode->Sarawak = Sarawak;
        newNode->Selangor = Selangor;
        newNode->Terengganu = Terengganu;
        newNode->WPKualaLumpur = WPKualaLumpur;
        newNode->WPLabuan = WPLabuan;
        newNode->next = nullptr;

        if (head == nullptr) {
            head = newNode;
        }
        else {
            StateData* current = head;
            while (current->next != nullptr) {
                current = current->next;
            }
            current->next = newNode;
        }
    }

    void displayList() {
        
        StateData* current = head;
        while (current != nullptr) {
            cout << string(50, '-') << endl;

            std::cout << "Year: " << current->year << ", Age Group: " << current->ageGroup << std::endl;
            std::cout << "Johor: " << current->Johor << ", Kedah: " << current->Kedah << std::endl;
            std::cout << "Kelantan: " << current->Kelantan << ", Melaka: " << current->Melaka << std::endl;
            std::cout << "Negeri Sembilan: " << current->NegeriSembilan << ", Pahang: " << current->Pahang << std::endl;
            std::cout << "Perak: " << current->Perak << ", Perlis: " << current->Perlis << std::endl;
            std::cout << "Perlis: " << current->Perlis << ", Pulau Pinang: " << current->PulauPinang << std::endl;
            std::cout << "Sabah: " << current->Sabah << ", Sarawak: " << current->Sarawak << std::endl;
            std::cout << "Selangor: " << current->Selangor << ", Terengganu: " << current->Terengganu << std::endl;
            std::cout << "WPKuala Lumpur: " << current->WPKualaLumpur << ", WPLabuan: " << current->WPKualaLumpur << std::endl;

           
            current = current->next;
        }
    }
};